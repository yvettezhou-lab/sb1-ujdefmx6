import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';
export default defineConfig({ plugins: [react(), VitePWA({ registerType: 'autoUpdate', manifest: { name: 'Carina', short_name: 'Carina', description: 'Personal local-first expense tracker', theme_color: '#111827', background_color: '#f8fafc', display: 'standalone', start_url: '/', scope: '/' } })] });
