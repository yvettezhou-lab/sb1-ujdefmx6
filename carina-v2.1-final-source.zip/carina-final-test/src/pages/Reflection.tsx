import { useEffect, useMemo, useState } from 'react';
import { db } from '@/database/db';
import type { Category, Transaction } from '@/models';

export function Reflection() {
  const [items, setItems] = useState<Transaction[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth());

  useEffect(() => {
    Promise.all([
      db.transactions.toArray(),
      db.categories.toArray()
    ]).then(([tx, cats]) => { setItems(tx); setCategories(cats); });
  }, []);

  const monthData = useMemo(() => {
    const start = new Date(year, month, 1).getTime();
    const end = new Date(year, month + 1, 1).getTime();
    const current = items.filter(t => t.dateTime >= start && t.dateTime < end);
    const income = current.filter(t => t.flow === 'income').reduce((s,t)=>s+t.amount,0);
    const expense = current.filter(t => t.flow === 'expense').reduce((s,t)=>s+t.amount,0);
    const byCategory = new Map<string,number>();
    current.filter(t => t.flow === 'expense').forEach(t => byCategory.set(t.categoryId, (byCategory.get(t.categoryId) ?? 0) + t.amount));
    const categoriesData = [...byCategory.entries()].map(([id,amount]) => ({
      id, name: categories.find(c=>c.id===id)?.name ?? 'Uncategorized', amount
    })).sort((a,b)=>b.amount-a.amount);
    return { income, expense, balance: income-expense, categoriesData };
  }, [items,categories,year,month]);

  const title = new Date(year, month, 1).toLocaleDateString('en-US',{month:'long',year:'numeric'});
  function shift(delta:number) { const d = new Date(year,month+delta,1); setYear(d.getFullYear()); setMonth(d.getMonth()); }

  const max = monthData.categoriesData[0]?.amount ?? 1;
  const sixMonthTrend = useMemo(() => Array.from({length: 6}, (_, i) => {
    const d = new Date(year, month - (5-i), 1);
    const start = d.getTime();
    const end = new Date(d.getFullYear(), d.getMonth()+1, 1).getTime();
    const rows = items.filter(t => t.dateTime >= start && t.dateTime < end);
    return {
      label: d.toLocaleDateString('en-US',{month:'short'}),
      expense: rows.filter(t=>t.flow==='expense').reduce((s,t)=>s+t.amount,0),
      income: rows.filter(t=>t.flow==='income').reduce((s,t)=>s+t.amount,0)
    };
  }), [items,year,month]);
  const trendMax = Math.max(1, ...sixMonthTrend.flatMap(x => [x.expense,x.income]));

  return (
    <section>
      <header className="hero-head inner-head">
        <div><div className="script-title">Reflection</div><div className="brand-subtitle">A MONTH IN REVIEW</div></div>
        <div className="month-switch"><button onClick={()=>shift(-1)}>‹</button><span>{title}</span><button onClick={()=>shift(1)}>›</button></div>
      </header>

      <div className="reflection-summary">
        <div><span>INCOME</span><strong className="positive">¥{monthData.income.toFixed(2)}</strong></div>
        <div><span>EXPENSE</span><strong>¥{monthData.expense.toFixed(2)}</strong></div>
        <div><span>NET FLOW</span><strong className={monthData.balance>=0?'positive':'negative'}>{monthData.balance>=0?'+':'−'} ¥{Math.abs(monthData.balance).toFixed(2)}</strong></div>
      </div>

      <div className="paper-panel">
        <div className="panel-kicker">WHERE YOUR LIFE FLOWS</div>
        <h2>Spending by category</h2>
        {monthData.categoriesData.length === 0 ? (
          <div className="empty"><span className="empty-script">A quiet month</span><p>No spending recorded yet.</p></div>
        ) : (
          <div className="category-bars">
            {monthData.categoriesData.map(c => (
              <div className="category-bar" key={c.id}>
                <div className="category-row"><span>{c.name}</span><strong>¥{c.amount.toFixed(2)}</strong></div>
                <div className="bar-track"><div className="bar-fill" style={{width:`${Math.max(5,c.amount/max*100)}%`}}/></div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="paper-panel trend-panel">
        <div className="panel-kicker">THE LAST SIX MONTHS</div>
        <h2>Money in motion</h2>
        <div className="trend-chart" aria-label="Six month income and expense trend">
          {sixMonthTrend.map((m,i) => (
            <div className="trend-month" key={`${m.label}-${i}`}>
              <div className="trend-columns">
                <div className="trend-bar income" style={{height:`${Math.max(3,m.income/trendMax*100)}%`}} />
                <div className="trend-bar expense" style={{height:`${Math.max(3,m.expense/trendMax*100)}%`}} />
              </div>
              <span>{m.label}</span>
            </div>
          ))}
        </div>
        <div className="trend-legend"><span><i className="income-dot"/> Income</span><span><i className="expense-dot"/> Expense</span></div>
      </div>

      <div className="reflection-note">
        <span className="script-caption">A small note</span>
        <p>{monthData.expense === 0 ? 'Every ledger has quiet pages.' : monthData.balance >= 0 ? 'A month in balance is worth remembering.' : 'Some months are for spending. The ledger simply remembers.'}</p>
      </div>
    </section>
  );
}
