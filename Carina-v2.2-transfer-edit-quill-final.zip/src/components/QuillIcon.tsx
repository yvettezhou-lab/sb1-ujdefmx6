export function QuillIcon({ size = 20, strokeWidth = 1.7 }: { size?: number; strokeWidth?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <path d="M20.7 3.3C16.2 3.5 11.8 5.2 8.6 8.4c-2.4 2.4-3.2 5.1-2.9 7.3l-2.2 2.2" stroke="currentColor" strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M20.7 3.3c-.2 4.5-1.9 8.9-5.1 12.1-2.4 2.4-5.1 3.2-7.3 2.9l-2.6 2.6" stroke="currentColor" strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M6.1 17.9 3.5 20.5M8.4 8.6l7 7" stroke="currentColor" strokeWidth={strokeWidth} strokeLinecap="round"/>
      <path d="M10.2 6.8c1.4 2.2 3.3 4.1 5.5 5.5" stroke="currentColor" strokeWidth={strokeWidth} strokeLinecap="round" opacity=".72"/>
    </svg>
  );
}
